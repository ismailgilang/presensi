<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="{{ asset('template/css/styles.css') }}" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #ced4da;
        }

        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 9999;
            /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
        }

        /* Modal Content */
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 60%;
            height: 250px;
            max-width: 600px;
            border-radius: 10px;
        }

        /* Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .container {
            background-color: white;
            height: max-content;
            margin-top: 50px;
            padding-bottom: 20px;
            border-radius: 10px;
        }

        .form-select {
            border: 1px solid #ced4da;
            /* Menambahkan border pada select */
            border-radius: 4px;
            /* Mengatur border radius */
            height: calc(2.25rem + 2px);
            /* Menyesuaikan tinggi dengan input lain */
            /* Menengahkan teks */
        }

        .select2-container--bootstrap4 .select2-selection--single {
            height: calc(2.25rem + 2px);
            /* Menyesuaikan tinggi dengan input lain */
            border: 1px solid #ced4da;
            /* Menambahkan border pada select */
            border-radius: 4px;
            /* Mengatur border radius */
            display: flex;
            align-items: center;
        }

        .calendar {
            margin-top: 20px;
        }

        .calendar th {
            text-align: center;
            font-size: 11px;
            vertical-align: middle;
        }

        .calendar td {
            text-align: center;
            font-size: 11px;
            vertical-align: middle;
        }

        .inputjs {
            width: 50px;
            border: none;
            pointer-events: none;
            text-align: center;
        }

        .ket {
            -webkit-appearance: none;
            /* Untuk Safari dan Chrome */
            -moz-appearance: none;
            /* Untuk Firefox */
            appearance: none;
            text-align: center;
            width: 5px;
            border-radius: 20px;
        }
    </style>
</head>

<body>
    <div class="container" style="padding-top: 30px;">
        <div class="form-group">
            <a href="/dashboard-admin/jadwal" class="btn btn-success">Kembali</a>
        </div>
        <div class="table-responsive">
            <div class="form-group" style="padding-top: 20px;">
                <label for="userSelect" class="form-label">Unit</label>
                <select name="unit" class="form-select select2" id="userSelect">
                    <option value="">Pilih Unit</option>
                    @foreach($users->unique() as $id => $unit)
                    <option value="{{ $unit }}">{{ $unit }}</option>
                    @endforeach
                </select>
            </div>
            <div class="row justify-content-center">
                <div class="col-md">

                    <table class="table table-bordered calendar" id="dataTable">
                        <thead>
                            <tr>
                                <th rowspan="3" style="width: 205px;">Nama</th>
                                <th rowspan="3" style="width: 200px;">NIK</th>
                            <tr>
                                @foreach($dates as $data)
                                <th>{{ $data['date'] }}</th>
                                @endforeach
                            </tr>
                            <tr>
                                @foreach($dates as $data)
                                <th>{{ $data['day'] }}</th>
                                @endforeach
                            </tr>
                        </thead>

                        <tbody id="tbody">

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="info" style="display: flex; justify-content:space-between; align-items:center;">
            <button id="saveDataBtn" class="btn btn-primary" style="margin-top:20px">Simpan Data</button>
        </div>
        <div class="d-flex justify-content-center mt-3" style="gap: 10px;">
            <span style="color:white;background-color: green; padding:0 5px 0 5px">P = Pagi</span>
            <span style="color:white;background-color: grey; padding:0 5px 0 5px">M = Malam</span>
            <span style="color:white;background-color: purple; padding:0 5px 0 5px">S = Siang</span>
            <span style="color:white;background-color: maroon; padding:0 5px 0 5px">L = Lembur</span>
            <span style="color:white;background-color: red; padding:0 5px 0 5px">O = Offline</span>
            <span style="color:white;background-color: brown; padding:0 5px 0 5px">SH = Setengah hari</span>
            <span style="color:white;background-color: blue; padding:0 5px 0 5px">PM = 24jam</span>
        </div>
    </div>
    <!-- modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Data Berhasil di Simpan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="pesan"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <div class="but"><a href="/dashboard-admin/jadwal" class="btn btn-primary">Oke</a></div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: 'bootstrap4'
            });

            $('#userSelect').change(function() {
                var unit = $(this).val();
                var tbody = $('#dataTable tbody');
                var displayedNiks = {}; // Objek untuk menyimpan NIK yang sudah ditampilkan

                tbody.empty(); // Kosongkan tabel sebelum menambahkan data baru
                if (unit) {
                    $.ajax({
                        url: '/get-data-unit/' + unit,
                        type: 'GET',
                        success: function(response) {
                            var data = response;
                            $.each(data, function(index, item) {
                                // Periksa apakah NIK sudah ditampilkan sebelumnya

                                if (!displayedNiks[item.nik]) {
                                    var inputElement = '<input class="inputjs" type="text" name="name[]" value="' + item.name + '">';
                                    var inputElement2 = '<input class="inputjs" type="text" name="nik[]" value="' + item.nik + '">';
                                    var selectHTML = ` 
                                                        <input type="hidden" name="name[]" id="nameInput"  value="` + item.name + `">
                                                        <input type="hidden" name="nik[]" id="nikInput" value="` + item.nik + `">
                                                        @foreach($dates as $data)
                                                            <td style="padding: 0; margin:0">
                                                            <select class="ket" name="{{ $loop->iteration }}"  style="width: 23px;background-color: #ffffff;" >
                                                                <option value="pagi">P</option>
                                                                <option value="malam">M</option>
                                                                <option value="siang">S</option>
                                                                <option value="lembur">L</option>
                                                                <option value="sethari">SH</option>
                                                                <option value="24jam">PM</option>
                                                                <option value="libur">O</option>
                                                                </select>
                                                            </td>
                                                        @endforeach
                                                        `;
                                    var row =
                                        '<tr>' +
                                        '<td>' + inputElement + '</td>' +
                                        '<td>' + inputElement2 + '</td>' +
                                        selectHTML +
                                        '</tr>';

                                    tbody.append(row);
                                    displayedNiks[item.nik] = true; // Tandai NIK sebagai sudah ditampilkan
                                }
                            });
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

        });
    </script>
    <script>
        $(document).ready(function() {
            // Fungsi untuk mengirim data dengan AJAX
            function sendDataToServer() {
                var entitiesData = []; // Array untuk menyimpan data entitas

                // Loop melalui setiap baris data dalam tabel
                $('#dataTable tbody tr').each(function() {
                    var entityData = {
                        name: $(this).find('#nameInput').val(), // Ambil nilai nama
                        nik: $(this).find('#nikInput').val(), // Ambil nilai NIK
                    };
                    // Loop melalui setiap kolom pilihan dalam baris data
                    for (var i = 1; i <= 31; i++) {
                        // Ambil nilai pilihan yang dipilih dan simpan ke dalam objek
                        entityData[i] = $(this).find('select[name="' + i + '"]').val();
                    }

                    // Tambahkan data entitas ke dalam array
                    entitiesData.push(entityData);
                });

                // Kirim data entitas ke server menggunakan AJAX
                $.ajax({
                    url: '/save-data', // Ganti dengan URL endpoint Anda
                    type: 'POST', // Metode HTTP
                    data: {
                        data: entitiesData, // Kirim array data entitas ke server
                        _token: $('meta[name="csrf-token"]').attr('content') // Kirim token CSRF
                    },
                    success: function(response) {
                        console.log(response); // Handle jika permintaan berhasil
                        $('#pesan').text(response.message);
                        $('#myModal').css('display', 'block');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText); // Handle jika terjadi kesalahan
                    }
                });
            }

            // Menambahkan event click pada tombol
            $('#saveDataBtn').click(function() {
                // Panggil fungsi untuk mengirim data ke server
                sendDataToServer();
            });
        });
    </script>
    <script>
        // Dapatkan elemen pop-up
        var modal = document.getElementById("myModal");

        // Dapatkan tombol tutup
        var span = document.getElementsByClassName("close")[0];

        // Saat pengguna mengklik tombol tutup, tutup pop-up
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Saat pengguna mengklik di luar area pop-up, tutup pop-up
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Fungsi untuk menampilkan pop-up
        function showPopup(message) {
            // Set pesan pada div pesan
            document.getElementById("pesan").innerHTML = message;
            // Tampilkan pop-up
            modal.style.display = "block";
        }
    </script>
    <script src="{{ asset('template/js/scripts.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="{{ asset('template/js/datatables-simple-demo.js') }} "></script>
</body>

</html>