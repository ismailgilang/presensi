<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <a href="/dashboard-admin/jadwal" class="btn btn-success mt-4">Kembali</a>
        <h2 class="mt-3">Edit Data</h2>
        <form action="{{ route('update-jadwal', $jadwal->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="{{ $jadwal->name }}">
            </div>
            <div class="form-group">
                <label for="nik">NIK:</label>
                <input type="text" class="form-control" id="nik" name="nik" value="{{ $jadwal->nik }}">
            </div>
            <div class="form-group">
                <label for="day">Select Shifts:</label>
                <div class="row" style="display: flex; flex-wrap:wrap; width:100%; gap:10px; justify-content:space-between">
                    @for ($i = 1; $i <= 31; $i++) <div class="col-md-1">
                        <label for="shift{{$i}}">{{$i}}</label>
                        <select class="form-control" id="shift{{ $i }}" name="{{ $i }}" style="width:80px">
                            <option value="{{$jadwal->$i}}">{{$jadwal->$i}}</option>
                            <optgroup label="Masuk">
                                <option value="pagi">Pagi</option>
                                <option value="malam">Malam</option>
                                <option value="siang">Siang</option>
                                <option value="lembur">Lembur</option>
                                <option value="ns">Non shift</option>
                                <option value="st">Set Hari</option>
                                <option value="offline">Offline</option>
                            </optgroup>
                            <optgroup label="Backup">
                                <option value="pm">24 jam</option>
                                <option value="md">Midle</option>
                            </optgroup>
                            <optgroup label="Tidak Masuk">
                                <option value="Izin">Izin</option>
                                <option value="Sakit">Sakit</option>
                                <option value="Cuti">Cuti</option>
                                <option value="TK">Tanpa ket</option>
                            </optgroup>
                        </select>
                </div>
                @endfor
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    </form>
    </div>
</body>

</html>