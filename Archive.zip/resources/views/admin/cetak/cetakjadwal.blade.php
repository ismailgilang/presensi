<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="{{ asset('template/css/styles.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css" />
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .calendar {
            margin-top: 20px;
        }

        .calendar th,
        .calendar td {
            text-align: center;
        }
    </style>
</head>

<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <a href="/dashboard-admin/jadwal" class="btn btn-success mt-4">Kembali</a>
                <h1 class="mt-4">Cetak Jadwal</h1>
                <div class="card mb-4 mt-3">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Data Jadwal Karyawan
                    </div>
                    <div id="myModal" class="modal">
                        <span class="close" onclick="closeModal()">&times;</span>
                        <div class="modal-content">
                            <img id="modalImg" src="" alt="">
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple" class="table table-bordered calendar">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>NIK</th>
                                    <th>Area</th>
                                    <th>1</th>
                                    <th>2</th>
                                    <th>3</th>
                                    <th>4</th>
                                    <th>5</th>
                                    <th>6</th>
                                    <th>7</th>
                                    <th>8</th>
                                    <th>9</th>
                                    <th>10</th>
                                    <th>11</th>
                                    <th>12</th>
                                    <th>13</th>
                                    <th>14</th>
                                    <th>15</th>
                                    <th>16</th>
                                    <th>17</th>
                                    <th>18</th>
                                    <th>19</th>
                                    <th>20</th>
                                    <th>21</th>
                                    <th>22</th>
                                    <th>23</th>
                                    <th>24</th>
                                    <th>25</th>
                                    <th>26</th>
                                    <th>27</th>
                                    <th>28</th>
                                    <th>29</th>
                                    <th>30</th>
                                    <th>31</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                $counter = 1;
                                @endphp
                                @foreach ($areas as $item)
                                <tr>
                                    <td>{{ $counter }}</td>
                                    <td>{{ $item->name }}</td>
                                    <td>{{ $item->nik }}</td>
                                    <td>{{$item->area}}</td>
                                    <td>{{ $item->{'1'} }}</td>
                                    <td>{{ $item->{'2'} }}</td>
                                    <td>{{ $item->{'3'} }}</td>
                                    <td>{{ $item->{'4'} }}</td>
                                    <td>{{ $item->{'5'} }}</td>
                                    <td>{{ $item->{'6'} }}</td>
                                    <td>{{ $item->{'7'} }}</td>
                                    <td>{{ $item->{'8'} }}</td>
                                    <td>{{ $item->{'9'} }}</td>
                                    <td>{{ $item->{'10'} }}</td>
                                    <td>{{ $item->{'11'} }}</td>
                                    <td>{{ $item->{'12'} }}</td>
                                    <td>{{ $item->{'13'} }}</td>
                                    <td>{{ $item->{'14'} }}</td>
                                    <td>{{ $item->{'15'} }}</td>
                                    <td>{{ $item->{'16'} }}</td>
                                    <td>{{ $item->{'17'} }}</td>
                                    <td>{{ $item->{'18'} }}</td>
                                    <td>{{ $item->{'19'} }}</td>
                                    <td>{{ $item->{'20'} }}</td>
                                    <td>{{ $item->{'21'} }}</td>
                                    <td>{{ $item->{'22'} }}</td>
                                    <td>{{ $item->{'23'} }}</td>
                                    <td>{{ $item->{'24'} }}</td>
                                    <td>{{ $item->{'25'} }}</td>
                                    <td>{{ $item->{'26'} }}</td>
                                    <td>{{ $item->{'27'} }}</td>
                                    <td>{{ $item->{'28'} }}</td>
                                    <td>{{ $item->{'29'} }}</td>
                                    <td>{{ $item->{'30'} }}</td>
                                    <td>{{ $item->{'31'} }}</td>
                                    <!-- <td style=" display: flex; gap :10px;">
                            <button type=" button" class="btn btn-warning" style="width: 40px;height:40px;"><i class="fas fa-pencil"></i></button>
                            <button type="button" class="btn btn-danger" style="width: 40px;height:40px;"><i class="fas fa-trash"></i></button>
                            </td> -->
                                </tr>
                                @php
                                $counter++;
                                @endphp
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
    <script>
        $(document).ready(function() {
            $("#datatablesSimple").DataTable({
                dom: "Bfrtip",
                buttons: ["excelHtml5", "pdfHtml5"],
                searching: false,
                info: false,
                paging: false,
            })
        })
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="{{ asset('template/js/scripts.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="{{ asset('template/js/datatables-simple-demo.js') }} "></script>
</body>

</html>