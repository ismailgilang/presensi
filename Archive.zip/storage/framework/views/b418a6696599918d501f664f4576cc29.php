<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
<h1>Surat Pengajuan Tugas Security</h1>
  <p><strong>Tujuan:</strong> Penugasan keamanan di area perkantoran.</p>
  <p><strong>Perihal:</strong> Permohonan Penugasan Security</p>
  <p><strong>Kepada Yth.,</strong></p>
  <p>Dengan hormat,</p>
  <p>Kami yang bertanda tangan di bawah ini:</p>
  <h2>Detail Pengaju</h2>
  <p><strong>Nama:</strong> John Doe</p>
  <p><strong>Jabatan:</strong> Security Manager</p>
  <p><strong>Perusahaan:</strong> Contoh Perusahaan</p>
  <p>Bermaksud untuk mengajukan penugasan keamanan di area perkantoran kami.</p>
  <p>Adapun rincian penugasan adalah sebagai berikut:</p>
  <ul>
    <li>Pengawasan keamanan di pintu masuk dan keluar.</li>
    <li>Patroli rutin di seluruh area perkantoran.</li>
    <li>Pemeriksaan identitas setiap orang yang masuk ke area terbatas.</li>
  </ul>
  <p>Demikianlah surat pengajuan tugas ini kami sampaikan. Atas perhatian dan kerjasamanya, kami ucapkan terima kasih.</p>
  <p>Hormat kami,</p>
  <p>John Doe</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//user/surat.blade.php ENDPATH**/ ?>