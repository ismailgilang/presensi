<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('template/css/styles.css')); ?>" rel="stylesheet" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #121212;
      color: #fff;
    }

    .navbar {
      background-color: #343a40 !important;
      width: 100%;
    }

    .navbar-brand {
      padding-left: 20px;
    }

    .navbar-nav {
      width: 98%;
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }

    .nav-link {
      color: #fff !important;
    }

    .container {
      width: 100%;
      height: max-content;
      margin: 0;
      display: flex;
      margin: auto;
    }

    thead>tr>th {
      color: white;
    }

    .row {
      margin-top: 40px;
      width: 100%;
      height: max-content;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 1px;
    }

    .card {
      background-color: #1e1e1e;
      color: #fff;
      border: none;
    }

    .card-header {
      background-color: #343a40;
      border-bottom: none;
    }

    .form-check-label {
      color: #fff;
    }

    .btn-primary {
      background-color: #007bff !important;
      border: none;
    }

    .btn-primary:hover {
      background-color: #0056b3 !important;
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="<?php echo e(url('/dashboard-user')); ?>">Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboard-user/patroli')); ?>">Patroli</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboard-user/absen')); ?>">Absen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/logout')); ?>">Logout</a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <div class="row">
      <div class="col-md-11">
        <div class="card">
          <div class="card-header">
            Data Absen
          </div>
          <div class="card-body">
            <!-- Contoh hasil absen -->
            <p>Anda dapat melihat hasil absensi anda setelah melakukan absensi</p>
            <table class="table table-dark">
              <div class="card mb-4">
                <div class="card-header">
                  <i class="fas fa-table me-1"></i>
                  DataTable Example
                </div>
                <div class="card-body">
                  <table id="datatablesSimple" style="-webkit-text-fill-color: white;">
                    <thead>
                      <tr>
                        <th>Nama</th>
                        <th>Posisi</th>
                        <th>Tempat Tugas</th>
                        <th>Alamat</th>
                        <th>Photo</th>
                        <th>Salary</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Office</th>
                        <th>Age</th>
                        <th>Start date</th>
                        <th>Salary</th>
                      </tr>
                    </tfoot>
                    <tbody>
                      <tr>
                        <td>Tiger Nixon</td>
                        <td>System Architect</td>
                        <td>Edinburgh</td>
                        <td>61</td>
                        <td>2011/04/25</td>
                        <td>$320,800</td>
                      </tr>
                      <tr>
                        <td>Garrett Winters</td>
                        <td>Accountant</td>
                        <td>Tokyo</td>
                        <td>63</td>
                        <td>2011/07/25</td>
                        <td>$170,750</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('template/js/scripts.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('template/assets/demo/chart-area-demo.js')); ?>"></script>
  <script src="<?php echo e(asset('template/assets/demo/chart-bar-demo.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('template/js/datatables-simple-demo.js')); ?> "></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//user/dashboardU.blade.php ENDPATH**/ ?>