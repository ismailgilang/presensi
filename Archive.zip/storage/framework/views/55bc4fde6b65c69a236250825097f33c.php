
<?php $__env->startSection('title2', 'Patroli'); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 mb-lg-0 mb-4">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Data Patroli</h6>
                </div>

            </div>
            <div class="table-responsive mt-3">
                <table class="display table align-items-center " id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">No</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Name</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">NIK</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Location</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Situasi</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Foto Patroli</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Foto Sekitar</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Keterangan</h6>
                                </div>
                            </th>
                            <th>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0">Option</h6>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 1;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo e($counter); ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"> <?php echo e($item->name); ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"> <?php echo e($item->nik); ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"> <?php echo e($item->location); ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo e($item->situasi); ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <img src="<?php echo e(asset('storage/' . $item->fotop)); ?>" class="img-thumbnail" alt="Fotop">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <img src="<?php echo e(asset('storage/' . $item->fotos)); ?>" class="img-thumbnail" alt="Fotos">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo e($item->ket); ?></h6>
                                </div>
                            </td>
                            <td style="display: flex; gap :10px; ">
                                <a href="<?php echo e(route('edit-karyawan', ['id' => $item->id])); ?>" class="btn btn-warning">
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <a href="<?php echo e(route('hpatroli', ['id' => $item->id])); ?>" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $counter++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php if(session('success') || $errors->any()): ?>
<!-- Modal -->
<div class="modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Pesan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if(session('success')): ?>
                <div>
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
    // Menampilkan modal saat halaman dimuat jika ada pesan sukses atau kesalahan
    window.onload = function() {
        var myModal = new bootstrap.Modal(document.getElementById('exampleModal'));
        myModal.show();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/admin/patroli.blade.php ENDPATH**/ ?>