<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Loading Screen</title>
  <style>
    body {
      background-color: #121212;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .loading-container {
      text-align: center;
    }

    .loading-icon {
      font-size: 50px;
      margin-bottom: 20px;
    }

    .loading-text {
      font-size: 20px;
    }
  </style>
</head>

<body>

  <div class="loading-container">
    <div class="loading-icon">
      <i class="fas fa-spinner fa-spin"></i>
    </div>
  </div>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/loading.blade.php ENDPATH**/ ?>