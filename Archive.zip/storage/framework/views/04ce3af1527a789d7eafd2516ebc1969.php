<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #121212;
            color: #fff;
            display: flex;
            flex-direction: column;
        }

        .navbar {
            background-color: #343a40 !important;
        }

        .navbar-brand {
            padding-left: 20px;
        }

        .navbar-nav {
            width: 98%;
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .nav-link {
            color: #fff !important;
        }

        .container {
            width: 100%;
            height: 500px;
            margin: auto;
            display: flex;
            justify-content: center;
        }

        .row {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            background-color: #1e1e1e;
            color: #fff;
            border: none;
            height: max-content;
            margin-top: 20px;

        }

        .card-header {
            background-color: #343a40;
            border-bottom: none;
        }

        .form-check-label {
            color: #fff;
        }

        h1 {
            color: #ffffff;
        }

        .section {
            background-color: #ffffff;
            padding: 50px 30px;
            border: 1.5px solid #b2b2b2;
            border-radius: 0.25em;
            box-shadow: 0 20px 25px rgba(0, 0, 0, 0.25);
        }

        #my-qr-reader {
            padding: 20px !important;
            border: 1.5px solid #b2b2b2 !important;
            border-radius: 8px;
        }

        #my-qr-reader img[alt="Info icon"] {
            display: none;
        }

        #my-qr-reader img[alt="Camera based scan"] {
            width: 100px !important;
            height: 100px !important;
        }

        button {
            padding: 10px 20px;
            border: 1px solid #b2b2b2;
            outline: none;
            border-radius: 0.25em;
            color: white;
            font-size: 15px;
            cursor: pointer;
            margin-top: 15px;
            margin-bottom: 10px;
            background-color: #008000ad;
            transition: 0.3s background-color;
        }

        button:hover {
            background-color: #008000;
        }

        #html5-qrcode-anchor-scan-type-change {
            text-decoration: none !important;
            color: #1d9bf0;
        }

        video {
            width: 100% !important;
            border: 1px solid #b2b2b2 !important;
            border-radius: 0.25em;
        }


        @media only screen and (max-width: 1190px) {
            video {
                height: 300px;
            }

            #qr-reader {
                width: 300px;
            }

        }

        @media only screen and (max-width: 600px) {
            video {
                height: 150px;
            }

            #qr-reader {
                width: 150px;
            }

        }

        @media only screen and (max-width: 300px) {
            video {
                height: 80px;
            }

            #qr-reader {
                width: 75px;
            }

            .navbar-brand {
                padding-left: 1px;
            }

            .take {
                width: 50px;
                height: 10px;
                font-size: 5px;
            }

            .image {
                height: 80px;
            }
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="<?php echo e(url('/dashboard-user')); ?>">Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/dashboard-user/patroli')); ?>">Patroli</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/dashboard-user/absen')); ?>">Absen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/logout')); ?>">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="modal fade" id="modalinput" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="location" style="color: black;">Lokasi:</label>
                            <input type="text" class="form-control" id="location" name="lokasi" readonly>
                        </div>
                        <div class="form-group">
                            <label for="sesi" style="color: black;">Kondisi</label>
                            <select class="form-control" id="sesi" name="situasi">
                                <option>Default select</option>
                                <option value="1">Aman</option>
                                <option value="2">Standar</option>
                                <option value="3">Tidak Aman</option>
                            </select>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Patroli
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="display: flex; flex-direction:column; justify-content:center; align-items:center">
                            <h1>Scan QR Codes</h1>
                            <div class="section">
                                <div id="my-qr-reader">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <script>
            var modal = document.getElementById("modalinput");
            var lokasi = document.getElementById("location");

            function domReady(fn) {
                if (
                    document.readyState === "complete" ||
                    document.readyState === "interactive"
                ) {
                    setTimeout(fn, 1000);
                } else {
                    document.addEventListener("DOMContentLoaded", fn);
                }
            }

            domReady(function() {

                // If found you qr code
                function onScanSuccess(decodeText, decodeResult) {
                    // alert("You Qr is : " + decodeText, decodeResult);
                    $('#modalinput').modal('show');
                    lokasi.value = decodeText, decodeResult;

                }

                let htmlscanner = new Html5QrcodeScanner(
                    "my-qr-reader", {
                        fps: 10,
                        qrbos: 250
                    }
                );
                htmlscanner.render(onScanSuccess);
            });
        </script>

        <!-- Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://unpkg.com/html5-qrcode"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//user/patroli.blade.php ENDPATH**/ ?>