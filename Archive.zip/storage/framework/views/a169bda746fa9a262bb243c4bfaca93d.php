
<?php $__env->startSection('title2', 'Jadwal'); ?>
<?php $__env->startSection('css'); ?>
<style>
    .tableFixHead {
        overflow: auto;
        height: 500px;

    }

    .tableFixHead thead th {
        position: sticky;
        top: 0;
        z-index: 1;

    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        padding: 8px 16px;
    }

    td {
        border: 1px solid #eee;
    }

    th {
        background: grey;
    }

    .calendar {
        margin-top: 20px;
    }

    .calendar th,
    .calendar td {
        text-align: center;

    }

    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-menu {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        z-index: 1;
        left: -120px;
    }

    .dropdown:hover .dropdown-menu {
        display: block;
    }

    .dropdown-item {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-item:hover {
        background-color: #ddd;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 mb-lg-0 mb-4">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Data Anggota</h6>
                    <input type="text" id="cari" placeholder="Cari...">
                </div>
                <a href="<?php echo e(route('tambahjadwal')); ?>" class="btn btn-primary">Tambah</a>
                <a href="<?php echo e(route('cetakjadwal')); ?>" class="btn btn-primary">Cetak</a>
            </div>
            <div class="table-responsive mt-3">
                <div class="tableFixHead">
                    <table class="display table align-items-center " id="tabel-data">
                        <thead>
                            <tr>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">No</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">NIK</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">Name</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">Area</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">1</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">2</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">3</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">4</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">5</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">6</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">7</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">8</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">9</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">10</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">11</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">12</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">13</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">14</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">15</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">16</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">17</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">18</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">19</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">20</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">21</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">22</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">23</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">24</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">25</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">26</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">27</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">28</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">29</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">30</h6>
                                    </div>
                                </th>
                                <th>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">31</h6>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                </div>
                <tbody>
                    <?php
                    $counter = 1;
                    ?>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"><?php echo e($counter); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->name); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->nik); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"><?php echo e($item->area); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"><?php echo e($item->{'1'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'2'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'3'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'4'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'5'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'6'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'7'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'8'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'9'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'10'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"><?php echo e($item->{'11'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'12'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'13'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'14'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'15'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'16'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'17'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'18'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'19'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'20'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"><?php echo e($item->{'21'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'22'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'23'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'24'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'25'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'26'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'27'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'28'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'29'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'30'}); ?></h6>
                            </div>
                        </td>
                        <td>
                            <div class="text-center">
                                <h6 class="text-sm mb-0"> <?php echo e($item->{'31'}); ?></h6>
                            </div>
                        </td>
                        <td style="display: flex; gap :10px">
                            <a href="<?php echo e(route('edit-jadwal', $item->id)); ?>" class="btn btn-warning">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <a href="<?php echo e(route('hapus-jadwal', $item->id)); ?>" class=" btn btn-danger">
                                <i class="fa fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php
                    $counter++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('#cari').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $('#tabel-data tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/admin/jadwal.blade.php ENDPATH**/ ?>