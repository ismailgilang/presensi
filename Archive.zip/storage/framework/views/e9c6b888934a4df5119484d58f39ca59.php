<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assignment Submission</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    body {
      background-color: #121212;
      color: #fff;
    }
    .row{
      height: 100vh;
    }
    .submission-container {
      margin-top: 50px;
    }
    .submission-container .card {
      background-color: #1e1e1e;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .submission-container .card-header {
      background-color: #343a40;
      color: #fff;
      border-bottom: none;
    }
    .submission-container .card-body input[type="file"] {
      background-color: #272727;
      border: none;
      border-bottom: 1px solid #444;
      color: #fff;
      margin-bottom: 20px;
    }
    .submission-container .card-body input[type="file"]::placeholder {
      color: #888;
    }
    .submission-container .card-body input[type="file"]:focus {
      box-shadow: none;
      border-bottom: 1px solid #666;
    }
    .submission-container .card-body .btn-primary {
      background-color: #007bff;
      border: none;
    }
    .submission-container .card-body .btn-primary:hover {
      background-color: #0056b3;
    }
    .submission-container .status-output {
      margin-top: 20px;
    }
    .form-control-file::-webkit-file-upload-button{
      background-color: #0056b3;
      color: white;
      border: transparent;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row justify-content-center align-items-center">
    <div class="col-md-6">
      <div class="submission-container">
        <div class="card">
          <div class="card-header text-center">
            <h3><i class="fas fa-file-upload"></i> Pengajuan Tugas</h3>
          </div>
          <div class="card-body">
            <form>
              <div class="form-group">
                <label for="file"><i class="fas fa-file"></i> Choose File</label>
                <input type="file" class="form-control-file" id="file">
              </div>
              <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-upload"></i> Submit</button>
            </form>
            <div class="status-output">
              <h5>Status: <span class="text-success">Diterima</span></h5>
              <a href="<?php echo e(url('/unduh-surat')); ?>"><button type="submit" class="btn btn-primary btn-block"><i class="fas fa-download"></i> Unduh Surat</button></a>
              <!-- Change the text-success to text-danger if status is not accepted -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//user/pengajuan.blade.php ENDPATH**/ ?>