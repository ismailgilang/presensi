<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="<?php echo e(asset('https://rawgit.com/sitepoint-editors/jsqrcode/master/src/qr_packed.js')); ?>"></script>
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #121212;
      color: #fff;
      display: flex;
      flex-direction: column;
    }

    .navbar {
      background-color: #343a40 !important;
    }

    .navbar-brand {
      padding-left: 20px;
    }

    .navbar-nav {
      width: 98%;
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }

    .nav-link {
      color: #fff !important;
    }

    .container {
      width: 100%;
      height: 500px;
      margin: auto;
      display: flex;
      justify-content: center;
    }

    .row {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .card {
      background-color: #1e1e1e;
      color: #fff;
      border: none;
      height: max-content;
      margin-top: 20px;

    }

    .card-header {
      background-color: #343a40;
      border-bottom: none;
    }

    .form-check-label {
      color: #fff;
    }

    .btn-primary {
      background-color: #007bff !important;
      border: none;
    }

    .btn-primary:hover {
      background-color: #0056b3 !important;
    }

    .take {
      margin-top: 20px;
      margin-bottom: 20px;
      color: black;
      background-color: gold;
      border: transparent;
      width: 200px;
      height: 40px;
      border-radius: 20px;
    }

    @media only screen and (max-width: 1190px) {
      video {
        height: 300px;
      }

    }

    @media only screen and (max-width: 600px) {
      video {
        height: 150px;
      }

    }

    @media only screen and (max-width: 300px) {
      video {
        height: 80px;
      }

      .navbar-brand {
        padding-left: 1px;
      }

      .take {
        width: 50px;
        height: 10px;
        font-size: 5px;
      }

      .image {
        height: 80px;
      }
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="<?php echo e(url('/dashboard-user')); ?>">Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboard-user/patroli')); ?>">Patroli</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboard-user/absen')); ?>">Absen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/logout')); ?>">Logout</a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            Absen
          </div>
          <div class="card-body">
            <div class="form-group" style="display: flex; flex-direction:column; justify-content:center; align-items:center">
              <video autoplay="true" id="video-webcam" style="display:flex;margin:auto ">
              </video>
              <button onclick="takeSnapshot()" class="take">Ambil Gambar</button>
            </div>
            <form action="<?php echo e(url('user/absen')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div id="imageContainer" name="image" class="image"></div>
              <div class="form-group">
                <input type="hidden" id="locationInput" name="rlocation">
              </div>
              <div class="form-group">
                <label for="location">Nama</label>
                <input type="text" class="form-control" id="location" name="name">
              </div>
              <div class="form-group">
                <label for="location">Lokasi:</label>
                <input type="text" class="form-control" id="location" name="lokasi">
              </div>
              <div class="form-group">
                <label for="tugas">Shift</label>
                <select class="form-control" id="sesi" name="tugas">
                  <option>Default select</option>
                  <option value="1">unpas</option>
                  <option value="2">MIM</option>
                  <option value="3">Toko Sepatu</option>
                </select>
              </div>
              <div class="form-group">
                <label for="identity">KTA</label>
                <input type="text" class="form-control" id="identity" name="kta">
              </div>
              <div class="form-group">
                <label for="sesi">Shift</label>
                <select class="form-control" id="sesi" name="sesi">
                  <option>Default select</option>
                  <option value="1">Pagi</option>
                  <option value="2">Siang</option>
                  <option value="3">Malam</option>
                </select>
              </div>
              <div class="form-group">
                <label for="ket">Keterangan</label>
                <select class="form-control" id="ket" name="ket">
                  <option>Default select</option>
                  <option value="1">Masuk</option>
                  <option value="2">Izin</option>
                  <option value="3">Sakit</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary mt-3">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('style/qrCodeScanner.js')); ?>"></script>
    <script src="<?php echo e(asset('style/location.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//user/absen.blade.php ENDPATH**/ ?>