<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #121212;
      color: #fff;
    }
    .navbar {
      background-color: #343a40 !important;
    }
    .nav-link {
      color: #fff !important;
    }
    .container {
      padding: 50px 0;
    }
    .card {
      background-color: #1e1e1e;
      color: #fff;
      border: none;
    }
    .card-header {
      background-color: #343a40;
      border-bottom: none;
    }
    .card-body {
      padding: 20px;
    }
    .form-check-label {
      color: #fff;
    }
    .btn-primary {
      background-color: #007bff !important;
      border: none;
    }
    .btn-primary:hover {
      background-color: #0056b3 !important;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#">Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="#">Absen</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Hasil Absen</a>
      </li>
    </ul>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          Absen
        </div>
        <div class="card-body">
          <form>
            <div class="form-group">
              <label for="exampleInputEmail1">Nama:</label>
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Waktu Absen:</label>
              <input type="datetime-local" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="form-check">
              <input type="checkbox" class="form-check-input" id="exampleCheck1">
              <label class="form-check-label" for="exampleCheck1">Izin</label>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Submit</button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          Hasil Absen
        </div>
        <div class="card-body">
          <!-- Contoh hasil absen -->
          <p>Anda telah melakukan absen pada tanggal 17 Februari 2024 jam 08:30. Absen ini tidak ada keterangan izin.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/dashboardU.blade.php ENDPATH**/ ?>