<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <p>RAJAWALI GARDA BUANA-86 SS</p>
        <p>Tangal sekarang</p>
        <table class="table" style="border-bottom: 1px solid transparent">
            <tr>
                <td style="width: 200px;">NAMA</td>
                <td>: <?php echo e($data->nama); ?></td>
            </tr>
            <tr>
                <td>UNIT KERJA</td>
                <td>: <?php echo e($data->unit); ?></td>
            </tr>
            <tr style="border-bottom: 1px solid black;">
                <td>NIK</td>
                <td>: <?php echo e($data->nik); ?></td>
            </tr>
        </table>
        <table class="table" style="border-bottom: 1px solid transparent">
            <tr>
                <td>GAJI POKOK</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->gaji); ?></td>
            </tr>
            <tr>
                <td>TUNJ. JABATAN</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->tunjabat); ?></td>
            </tr>
            <tr>
                <td>MASA KERJA</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->masa); ?></td>
            </tr>
            <tr>
                <td>TUNJ. TRANSPORT</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->tuntrans); ?></td>
            </tr>
            <tr>
                <td>TUNJ. MAKAN</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->tunjma); ?></td>
            </tr>
            <tr>
                <td>TUNJ. KLIEN</td>
                <td>:</td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->tunjangank); ?></td>
            </tr>
            <tr>
                <td>LEMBUR <span>(inc tunj. Mkn & trans)</span></td>
                <td>:</td>
                <td>1</td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->lemburan); ?></td>
            </tr>
            <tr>
                <td>BACKUP <span>(inc tunj. Mkn & trans)</span></td>
                <td>:</td>
                <td>0</td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->backup); ?></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td style="border-bottom: 1px solid black;"></td>
            </tr>
            <tr style="border-bottom: 1px solid black;">
                <td colspan="3" style="text-align: end;">GROSS</td>
                <td>= Rp.</td>
                <td style="text-align: end; ">hasil penjumlahan</td>
            </tr>
        </table>
        <table class=" table" style="border-bottom: 1px solid transparent">
            <tr>
                <td style="width:300px">BPJS KETENAGAKERJAAN</td>
                <td style="width: 165px;"></td>
                <td style="width: 190px;"></td>
                <td>= Rp.</td>
                <td style="width: 335px; text-align: end;"><?php echo e($data->bpjsk); ?></td>
            </tr>
            <tr>
                <td>BPJS KESEHATAN</td>
                <td></td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->bpjsks); ?></td>
            </tr>
            <tr>
                <td>CICILAN CASH BON</td>
                <td><span>-ke</span></td>
                <td><span>-dari</span></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->cashbon); ?></td>
            </tr>
            <tr>
                <td>CICILAN KOPERASI</td>
                <td><span>-ke</span></td>
                <td><span>-dari</span></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->cicilan); ?></td>
            </tr>
            <tr>
                <td>POTONGAN ABSEN</td>
                <td></td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->potabsen); ?></td>
            </tr>
            <tr>
                <td>TANGGUNG RENTENG</td>
                <td></td>
                <td></td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->tanggungr); ?></td>
            </tr>
            <tr>
                <td>DONASI</td>
                <td></td>
                <td></td>
                <td>= Rp.</td>
                <td style="border-bottom: 1px solid black; text-align: end;"><?php echo e($data->donasi); ?></td>
            </tr>
            <tr style="border-bottom: 1px solid black;">
                <td colspan="3" style="text-align: center;">TOTAL POTONGAN</td>
                <td>= Rp.</td>
                <td style="text-align: end;"><?php echo e($data->donasi); ?></td>
            </tr>
            <tr style="height: 60px; font-size:30px">
                <td colspan="3" style="text-align: end;">NETTO</td>
                <td> = Rp.</td>
                <td style="text-align: end;"><?php echo e($data->donasi); ?></td>
            </tr>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//admin/cetak/cetakgaji.blade.php ENDPATH**/ ?>