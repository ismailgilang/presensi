<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Sidebar with Bootstrap</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .wrapper{
        width: 100%;
        height: 100vh;
        display: flex;
    }
    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      width: 250px;
      background-color: #343a40;
      padding-top: 50px;
      z-index: 1000;
      transition: all 0.3s;
    }
    .sidebar2 {
      top: 0;
      left: 0;
      height: 100vh;
      width: 300px;
      padding-top: 50px;
      z-index: 1000;
      transition: all 0.3s;
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar ul li {
      padding: 8px 15px;
    }
    .sidebar ul li a {
      color: #fff;
      text-decoration: none;
      font-size: 18px;
    }
    .sidebar ul li:hover {
      background-color: #495057;
    }
    .content {
        width: 100%;
      padding: 20px;
      transition: all 0.3s;
    }
    .toggled .sidebar {
      display: none;
    }
    .toggled .sidebar2{
        display: none;
    }
    .toggled .content {
      margin-left: 0;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 0;
      }
      .sidebar2{
        width: 0;
      }
      .sidebar ul{
        display: none;
      }
      .toggled .sidebar {
        display: flex;
        position: fixed;
        width: 200px;
        height: 100vh;
      }
      .toggled .sidebar ul {
        display: block;
        position: fixed;
        width: 200px;
      }
      .toggled .sidebar2 {
        width: 200px;
      }
      .toggled .content {
        margin-left: 200px;
      }
    }
  </style>
</head>
<body>

<div class="wrapper">
    <div class="sidebar2"></div>
  <div class="sidebar">
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </div>

  <div id="content" class="content">
    <nav class="navbar navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" id="sidebarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <span class="navbar-brand">Toggle Sidebar</span>
    </nav>
    <h2>Main Content Area</h2>
    <p>This is the main content area. It will adjust when the sidebar is toggled.</p>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
  $(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
      $('.wrapper').toggleClass('toggled');
      $('.sidebar2').toggleClass('toggled');
    });
  });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appAbsen\resources\views//admin/dashboardA.blade.php ENDPATH**/ ?>