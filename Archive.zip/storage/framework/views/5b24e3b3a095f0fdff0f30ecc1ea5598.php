
<?php $__env->startSection('title2', 'Penugasan'); ?>
<?php $__env->startSection('css'); ?>
<style>
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-menu {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        z-index: 1;
        left: -120px;
    }

    .dropdown:hover .dropdown-menu {
        display: block;
    }

    .dropdown-item {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-item:hover {
        background-color: #ddd;
    }

    .buton {
        width: 100%;
        height: 70px;
        display: flex;
        justify-content: flex-end;
        align-items: flex-end;
    }

    .form-select {
        border: 1px solid #ced4da;
        /* Menambahkan border pada select */
        border-radius: 4px;
        /* Mengatur border radius */
        height: calc(2.25rem + 2px);
        /* Menyesuaikan tinggi dengan input lain */
        text-align-last: center;
        /* Menengahkan teks */
    }

    .select2-container--bootstrap4 .select2-selection--single {
        height: calc(2.25rem + 2px);
        /* Menyesuaikan tinggi dengan input lain */
        border: 1px solid #ced4da;
        /* Menambahkan border pada select */
        border-radius: 4px;
        /* Mengatur border radius */
        display: flex;
        align-items: center;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 mb-lg-0 mb-4">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Penugasan</h6>
                </div>

            </div>
            <div class="card mb-4 mt-3">
                <div class="card-body">
                    <form action="<?php echo e(route('cetak.tugas')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="userSelect" class="form-label">NIK</label>
                                    <select name="nik" class="form-select select2" id="userSelect" style="width: 100%;">
                                        <option value="">Pilih Pengguna</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id->nik); ?>"><?php echo e($id->nik); ?> | <?php echo e($id->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="unit" class="form-label">Unit</label>
                                    <input type="text" class="form-control" id="unit" name="unit">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="nama" name="nama" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="level" class="form-label">Level</label>
                                    <input type="text" class="form-control" id="level" name="level" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="buton">
                            <button type="submit" class="btn btn-primary" style="width: 475px;">Kirim</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap4'
        });

        $('#userSelect').change(function() {
            var nik = $(this).val();
            if (nik) {
                $.ajax({
                    url: '/validate-tugas/' + nik,
                    type: 'GET',
                    success: function(response) {
                        $('#unit').val(response.area);
                        $('#nama').val(response.name);
                        $('#level').val(response.jabatan);
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            } else {
                $('#nama').val('');
                $('#level').val('');
                $('#unit').val('');
            }
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/admin/penugasan.blade.php ENDPATH**/ ?>