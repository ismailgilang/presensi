<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Complete Profile</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    body {
      background-color: #121212;
      color: #fff;
    }
    .row{
        height: 100vh;
    }
    .profile-container .card {
      background-color: #1e1e1e;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .profile-container .card-header {
      background-color: #343a40;
      color: #fff;
      border-bottom: none;
    }
    .profile-container .card-body input[type="text"],
    .profile-container .card-body input[type="file"],
    .profile-container .card-body input[type="date"] {
      background-color: #272727;
      border: none;
      border-bottom: 1px solid #444;
      color: #fff;
      margin-bottom: 20px;
    }
    .profile-container .card-body input[type="text"]::placeholder {
      color: white;
    }
    .profile-container .card-body input[type="text"]:focus,
    .profile-container .card-body input[type="file"]:focus {
      box-shadow: none;
      border-bottom: 1px solid #666;
    }
    .profile-container .card-body .btn-primary {
      background-color: #007bff;
      border: none;
    }
    .profile-container .card-body .btn-primary:hover {
      background-color: #0056b3;
    }
    
  </style>
</head>
<body>

<div class="container">
  <div class="row justify-content-center align-items-center">
    <div class="col-md-6">
      <div class="profile-container">
        <div class="card">
          <div class="card-header text-center">
            <h3><i class="fas fa-user"></i> Complete Your Profile</h3>
          </div>
          <div class="card-body">
            <form>
            <div class="form-group">
                <label for="photo"><i class="fas fa-image"></i> Photo</label>
                <input type="file" class="form-control-file" id="photo">
              </div>
              <div class="form-group">
                <label for="fullname"><i class="fas fa-user"></i> Full Name</label>
                <input type="text" class="form-control" id="fullname" placeholder="Enter full name">
              </div>
              <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email</label>
                <input type="text" class="form-control" id="email" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="dob"><i class="fas fa-calendar"></i> Date of Birth</label>
                <input type="date" class="form-control" id="dob" placeholder="Enter your date of birth">
              </div>
              <div class="form-group">
                <label for="address"><i class="fas fa-globe"></i> Address</label>
                <input type="text" class="form-control" id="address" placeholder="Enter your address">
              </div>
              <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-save"></i> Save</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/next.blade.php ENDPATH**/ ?>