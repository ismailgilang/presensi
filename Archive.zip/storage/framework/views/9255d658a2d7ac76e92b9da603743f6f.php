<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('template/css/styles.css')); ?>" rel="stylesheet" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #121212;
      color: #fff;
    }

    .navbar {
      background-color: #343a40 !important;
      width: 100%;
    }

    .navbar-brand {
      padding-left: 20px;
    }

    .navbar-nav {
      width: 98%;
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }

    .nav-link {
      color: #fff !important;
    }

    .container {
      width: 100%;
      height: max-content;
      margin: 0;
      display: flex;
      margin: auto;
    }

    thead>tr>th {
      color: white;
    }

    .row {
      margin-top: 40px;
      width: 100%;
      height: max-content;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 1px;
    }

    .card {
      background-color: #1e1e1e;
      color: #fff;
      border: none;
    }

    .card-header {
      background-color: #343a40;
      border-bottom: none;
    }

    .form-check-label {
      color: #fff;
    }

    .btn-primary {
      background-color: #007bff !important;
      border: none;
    }

    .btn-primary:hover {
      background-color: #0056b3 !important;
    }

    .imglong {
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .profile-card {
      background-color: #1f1f1f;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }

    .profile-picture {
      border-radius: 50%;
      width: 150px;
      height: 150px;
      object-fit: cover;
      margin-bottom: 20px;
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="<?php echo e(url('/dashboardU')); ?>">Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboardU/dataabsen')); ?>">Data absen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboardU/patroli')); ?>">Patroli</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboardU/laporan')); ?>">Laporan</a>
        </li>
        <?php if(isset($jadwal)): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/dashboardU/absen')); ?>">Absen</a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/logout')); ?>">Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="profile-card text-center">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla convallis libero sed tortor pulvinar, non sodales ligula consequat.</p>
          <div class="social-links">
            <a href="#" class="btn btn-outline-light mr-2"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="btn btn-outline-light mr-2"><i class="fab fa-twitter"></i></a>
            <a href="#" class="btn btn-outline-light"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Font Awesome -->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('template/js/scripts.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/user/laporan.blade.php ENDPATH**/ ?>