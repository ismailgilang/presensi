<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Data</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f2f3f4;
        }

        .card {
            background-color: #5e72e4;
            /* Warna latar belakang card */
        }

        label {
            color: white;
        }

        .form-control {
            background-color: white;
            /* Warna latar belakang input */
            color: #fff;
            /* Warna teks input */
        }

        .form-control:focus {
            border-color: #007bff;
            /* Warna border input saat fokus */
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
            /* Efek shadow saat fokus */
        }

        .btn-primary {
            background-color: #007bff;
            /* Warna latar belakang tombol primer */
            border-color: #007bff;
            /* Warna border tombol primer */
        }

        .btn-primary:hover {
            background-color: #0056b3;
            /* Warna latar belakang tombol primer saat hover */
            border-color: #0056b3;
            /* Warna border tombol primer saat hover */
        }

        .btn-warning {
            background-color: #ffc107;
            /* Warna latar belakang tombol peringatan */
            border-color: #ffc107;
            /* Warna border tombol peringatan */
        }

        .btn-warning:hover {
            background-color: #e0a800;
            /* Warna latar belakang tombol peringatan saat hover */
            border-color: #e0a800;
            /* Warna border tombol peringatan saat hover */
        }

        .button-group {
            display: flex;
            width: 100%;
        }

        .back {
            width: 100%;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <h2 class="text-center " style="color: white;">Tambah Data</h2>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <img class="img-fluid mx-auto mb-5 mt-2" src=" <?php echo e(asset('foto/logo.png')); ?>" alt="" style="width: 120px;">
                            </div>
                        </div>
                        <form action="<?php echo e(route('akun_admin')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="button-group">
                                <a href="/akun_admin" class="btn btn-md btn-danger"> <i class="fa fa-arrow"></i> Kembali</a>
                                <div class="back">
                                    <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                                    <button type="reset" class="btn btn-md btn-warning">RESET</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Mengambil data terakhir dari Laravel menggunakan fetch API
        fetch('/last-id')
            .then(response => response.json())
            .then(data => {
                var lastId = data.lastId || 'RGB-86.10.00.0000';

                // Mendapatkan nomor terakhir dari ID sebelumnya
                var lastNumber = parseInt(lastId.split('.')[3]);

                // Menambahkan 1 untuk mendapatkan nomor berikutnya
                var nextNumber = lastNumber + 1;

                // Format nomor dengan leading zeros jika diperlukan
                var formattedNumber = ('0000' + nextNumber).slice(-4);

                const currentDate = new Date();

                // Mendapatkan nomor bulan (dalam format 01)
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');

                // Menghasilkan ID lengkap
                var randomId = 'RGB-86.10.' + month + '.' + formattedNumber;

                // Memasukkan ID ke dalam input dengan ID "nik"
                document.getElementById('nik').value = randomId;
            })
            .catch(error => console.error('Error:', error));
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\appAbsen\resources\views/admin/crud_akun/create.blade.php ENDPATH**/ ?>