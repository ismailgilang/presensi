<?php
header('location: public/');
